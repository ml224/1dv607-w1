﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;



namespace YachtClub.model
{
    class Member
    {
        private string _name;
        private long _personalNumber;
        private long _memberID;
        private List<Boat> _boatList;
        public Member(string name, long personalNumber, long memberID)
        {
            _name = name;
            _personalNumber = personalNumber;
            _memberID = memberID;
            _boatList = new List<Boat>();
        }

        public long GetMemberID()
        {
            return _memberID;
        }

        public string GetMemberName()
        {
            return _name;
        }

        public long GetMemberPersonalNumber()
        {
            return _personalNumber;
        }
      
        public void UpdateMemberName(string newName)
        {
            _name = newName;
        }

        public void UpdateMemberPersonalNumber(long newPersonalNumber)
        {
            _personalNumber = newPersonalNumber;
        }

        //boat stuff

       public List<Boat> GetBoatList()
        {
            return _boatList;
        }

        public void AddBoat(string type, int length)
        {
            _boatList.Add(new Boat(length, type));
        }

        public void RemoveBoat(int index)
        {
            if(index < _boatList.Count)
            {
                _boatList.Remove(_boatList[index]);

            }
           
        }

        public bool HasBoats()
        {
            return _boatList.Any();
        }

    }
}

   


