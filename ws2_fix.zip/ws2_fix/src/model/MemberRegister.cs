﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Data;


namespace YachtClub.model
{
    class MemberRegister
    {
        private List<Member> _membersList;
        public MemberRegister()
        {
            _membersList = new List<Member>();
        }

        public List<Member> GetMembersList()
        {
            return _membersList;
        }

        public Member GetMemberByID(long id)
        {
            return _membersList.Find(m => m.GetMemberID() == id);
        }
        
        public void AddMember(string name, long personalNumber, long memberID)
        {
            _membersList.Add(new Member(name, personalNumber, memberID));
        }

        public void DeleteMember(long memberID)
        {
                _membersList.Remove(GetMemberByID(memberID));
        }

      
    }
}

