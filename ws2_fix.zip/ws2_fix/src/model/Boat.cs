﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.model
{
    class Boat
    {
        private int _length;
        private string _type;

        public Boat(int length, string type)
        {
            _length = length;
            _type = type;
        }

        public int GetLength()
        {
            return _length;
        }

        public string GetBoatType()
        {
            return _type;
        }
        public void UpdateBoatType(string type)
        {
            _type = type;
        }

        public void UpdateBoatLength(int length)
        {
            _length = length;
        }
    }
}
