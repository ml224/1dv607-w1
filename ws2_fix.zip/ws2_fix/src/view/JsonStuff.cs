﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class JsonStuff
    {
        public string BoatJsonString(string boatType, int boatLength)
        {
            return @"{'type': '" + boatType + "', 'length': " + boatLength + "}";
        }

        public string MemberJsonString(long memberID, string memberName, long memberPersonalNumber, string boats)
        {
            return "{ 'memberID' : " + memberID + ", 'name': '" + memberName + "', 'personalNumber': " +
                    memberPersonalNumber + ", 'boats': [" + boats + "]}";
        }
    }
}
