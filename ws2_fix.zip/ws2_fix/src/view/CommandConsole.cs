﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class CommandConsole : MainConsole
    {
        public string CommandOptions()
        {
            Console.WriteLine("\n\nCommands available: \n" +
                "list -v = List Members Verbose View\n" +
                "list -c = List Members Compact View\n" +
                "list -m = List Member\n" +
                "add -m = Add Member \n" +
                "add -b = Add Boat To Member\n" +
                "delete -m = Delete Member\n" +
                "delete -b = Delete Boat\n" +
                "change -m = Change Member Information\n" +
                "change -b = Change Boat Information\n\n");
            return Console.ReadLine();
        }

     
    }
}
