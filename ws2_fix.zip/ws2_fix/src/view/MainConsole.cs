﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class MainConsole
    {
        public long GetMemberID()
        {
            Console.WriteLine("Enter Member ID: ");
            string id = Console.ReadLine();

            while (!long.TryParse(id, out long result))
            {
                Console.WriteLine("Numbers only please! Try again: ");
                id = Console.ReadLine();
            }

            return long.Parse(id);
        }
        public string GetInput()
        {
            return Console.ReadLine();
        }

        public void NoMember()
        {
            Console.WriteLine("There is no member with that id! ");
        }

        public void NotValidInput()
        {
            Console.WriteLine("Oops! Not a valid input");
        }
        public void TryAgain()
        {
            Console.WriteLine("Try again: ");
        }

    }
}
