﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class MemberConsole : MainConsole
    {
        public bool WantsToUpdateName()
        {
            Console.WriteLine("Do you want to update members name? Press 'y' ");
            return Console.ReadLine() == "y";
        }
        public bool WantsToUpdatePN()
        {
            Console.WriteLine("Do you want to update members personal number? Press 'y'");
            return Console.ReadLine() == "y";
        }
        public string NewName()
        {
            Console.WriteLine("Enter new member name: ");
            return Console.ReadLine();
        }

        public long NewPN()
        {
            Console.WriteLine("Enter new personal number: ");
            string returnable = Console.ReadLine();

            while (!long.TryParse(returnable, out long longNr))
            {
                Console.WriteLine("Try again! You must enter only numbers: ");
                returnable = Console.ReadLine();
            }

            return long.Parse(returnable);
        }

        public string CompactView(string name, long id, int boatAmount)
        {
            return $"-------------------------\nName: {name}\nMember ID: {id}\nNumber of boats: {boatAmount}";
        }

        public void VerboseView(string name, long id, long pn)
        {
            Console.WriteLine($"-------------------------\nName: {name}\nMember ID: {id}\nPersonal Number: {pn}");
        }



    }
}
