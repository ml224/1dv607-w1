﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class BoatConsole : MainConsole
    {
        public string GetBoatType()
        {
            Console.WriteLine("Enter boat type: ");
            return Console.ReadLine();
        }

        public int GetBoatLength()
        {
            Console.WriteLine("Enter boat length (in m): ");
            var length = Console.ReadLine();

            while (!int.TryParse(length, out int result))
            {
                Console.WriteLine("Numbers only please! Try again:");
                length = Console.ReadLine();
            }

            return int.Parse(length);
        }

        public int GetBoatIndex()
        {
            Console.WriteLine($"Enter the index of the boat:\n");


            string index = Console.ReadLine();

            while (!int.TryParse(index, out int result))
            {
                Console.WriteLine("Try again:");
                index = Console.ReadLine();
            }

            return int.Parse(index);

        }
        public void ChangeOptions()
        {
            Console.WriteLine("1. Change Length\n2. Change Type");
        }
        public bool ChoseLength(string input)
        {
            return input == "1";
        }
        public bool ChoseType(string input)
        {
            return input == "2";
        }

        public void MemberHasNoBoats()
        {
            Console.WriteLine("Member has no boats!");
        }
        public void ListBoat(int index, string type, int length)
        {
            Console.WriteLine($"{index}. Type: {type}, Length: {length}");
        }

    }
}
