﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Reflection;

namespace YachtClub.controller
{
    class FileContent
    {
        private JArray _fileContent;
        private model.MemberRegister _register;
        private view.JsonStuff _json;

        private string _path;


        public FileContent(string path)
        {
            _path = path;
            _fileContent = JArray.Parse(File.ReadAllText(_path));
            Register = new model.MemberRegister();
            _json = new view.JsonStuff();
            
            //populating Register with file content
            AddMembers();
        }

        public model.MemberRegister Register
        {
            get { return _register; }
            private set { _register = value; }
        }


        //only used upon creation of this class
        private void AddMembers()
        {
            foreach (var member in _fileContent)
            {
                var memberID = member["memberID"].ToObject<long>();
                var memberPn = member["personalNumber"].ToObject<long>();
                var memberName = member["name"].ToString();

                Register.AddMember(memberName, memberPn, memberID);

                if (member["boats"].Count() > 0)
                {
                    foreach(var boat in member["boats"])
                    {
                        Register.GetMemberByID(memberID).AddBoat(boat["type"].ToString(), boat["length"].ToObject<int>());
                    }
                }
            }
        }

        private string addBoats(model.Member member)
        {
            string boats = "";

            var membersBoatList = member.GetBoatList();
            var last = membersBoatList.Last();

            foreach (var boat in membersBoatList)
            {
                boats += _json.BoatJsonString(boat.GetBoatType(), boat.GetLength()); 
            
                if (boat != last)
                {
                    boats += ", ";
                }
            }

            return boats;
        }

        public void UpdateFile()
        {
            JArray members = new JArray();

            foreach (model.Member member in _register.GetMembersList())
            {
                string boats = "";

                if (member.GetBoatList().Count > 0)
                {
                    boats += addBoats(member);
                }

                string jsonString = _json.MemberJsonString(member.GetMemberID(), member.GetMemberName(), member.GetMemberPersonalNumber(), boats);

                members.Add(JObject.Parse(jsonString));
            }
            _fileContent = members;
            File.WriteAllText(_path, _fileContent.ToString());
        }
    }
}

