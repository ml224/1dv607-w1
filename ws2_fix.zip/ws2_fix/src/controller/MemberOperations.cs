﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.controller
{
    class MemberOperations
    {
        private view.MemberConsole _memberConsole;
        private model.MemberRegister _register;
        private BoatOperations _boatOperations;

        public MemberOperations(model.MemberRegister register, BoatOperations boatOperations)
        {
            _memberConsole = new view.MemberConsole();
            _boatOperations = boatOperations;
            _register = register;
        }

        private long NewID()
        {
            long nr = 0;
            foreach (model.Member member in _register.GetMembersList())
            {
                if (nr <= member.GetMemberID())
                {
                    nr = member.GetMemberID() + 1;
                }
            }
            return nr;
        }

        public void AddMemberToRegister()
        {
            _register.AddMember(_memberConsole.NewName(), _memberConsole.NewPN(), NewID());
        }

        public void DeleteMemberFromRegister()
        {
            var id = _memberConsole.GetMemberID();
            while (_register.GetMemberByID(id) == null)
            {
                _memberConsole.NoMember();
                _memberConsole.TryAgain();
                id = _memberConsole.GetMemberID();
            }
            _register.DeleteMember(id);
        }

        public void ChangeMember()
        {
            var id = _memberConsole.GetMemberID();
            
            while(_register.GetMemberByID(id) == null)
            {
                _memberConsole.NoMember();
                _memberConsole.TryAgain();
                id = _memberConsole.GetMemberID();
            }

            model.Member member = _register.GetMemberByID(id);

            if (_memberConsole.WantsToUpdateName())
            {
                member.UpdateMemberName(_memberConsole.NewName());
            }
            if (_memberConsole.WantsToUpdatePN())
            {
                member.UpdateMemberPersonalNumber(_memberConsole.NewPN());
            }
            
        }

        public void List(bool isVerbose)
        {
            foreach (model.Member member in _register.GetMembersList())
            {
                if (isVerbose)
                {
                    _memberConsole.VerboseView(member.GetMemberName(), member.GetMemberID(), member.GetMemberPersonalNumber());
                    if (member.HasBoats())
                    {
                        _boatOperations.ListBoats(member);
                    }
                }
                else
                {
                    Console.WriteLine(_memberConsole.CompactView(member.GetMemberName(), member.GetMemberID(), member.GetBoatList().Count));
                }
            }
        }
 
        public void ViewMember()
        {
            
            var member = _register.GetMemberByID(_memberConsole.GetMemberID());

            while (member == null)
            {
                _memberConsole.NoMember();
                _memberConsole.TryAgain();
                member = _register.GetMemberByID(_memberConsole.GetMemberID());
            }

            _memberConsole.VerboseView(member.GetMemberName(), member.GetMemberID(), member.GetMemberPersonalNumber());
            _boatOperations.ListBoats(member);
        }
    }
}

