﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.controller
{
    class BoatOperations
    {
        private model.MemberRegister _register;

        private view.CommandConsole _presentation;
        private view.BoatConsole _boatConsole;

        public BoatOperations(model.MemberRegister register)
        {
            _register = register;

            _presentation = new view.CommandConsole();
            _boatConsole = new view.BoatConsole();
        }

        public void AddBoat()
        {
            var id = _boatConsole.GetMemberID();

            while(_register.GetMemberByID(id) == null)
            {
                _boatConsole.NoMember();
                id = _boatConsole.GetMemberID();
            }

            var boatType = _boatConsole.GetBoatType();
            var boatLength = _boatConsole.GetBoatLength();
            
            _register.GetMemberByID(id).AddBoat(boatType, boatLength);
        }

        public void DeleteBoat()
        {
            var id = _boatConsole.GetMemberID();

            while(_register.GetMemberByID(id) == null)
            {
                _boatConsole.NoMember();
                _boatConsole.TryAgain();
                id = _boatConsole.GetMemberID();
            }

            var mmbr = _register.GetMemberByID(id);

            if (mmbr.HasBoats())
            {
                ListBoats(mmbr);
               
                int index = _boatConsole.GetBoatIndex();

                while(index >= mmbr.GetBoatList().Count)
                {
                    _boatConsole.NotValidInput();
                    _boatConsole.TryAgain();

                    ListBoats(mmbr);
                    index = _boatConsole.GetBoatIndex();
                }

                mmbr.RemoveBoat(index);
            }
            else
            {
                _boatConsole.MemberHasNoBoats();
            }
        }
        public void ChangeBoat()
        {
            var id = _boatConsole.GetMemberID();
            while(_register.GetMemberByID(id) == null)
            {
                _boatConsole.NoMember();
                id = _boatConsole.GetMemberID();
            }

            var mmbr = _register.GetMemberByID(id);

            if (mmbr.HasBoats())
            {
                ListBoats(mmbr);
                int boatIndex = _boatConsole.GetBoatIndex();

                while (boatIndex >= mmbr.GetBoatList().Count)
                {
                    _boatConsole.NotValidInput();
                    _boatConsole.TryAgain();

                    ListBoats(mmbr);
                    boatIndex = _boatConsole.GetBoatIndex();
                }

                _boatConsole.ChangeOptions();
                var choice = _boatConsole.GetInput();

                if (_boatConsole.ChoseLength(choice))
                {
                    UpdateBoatLength(mmbr, boatIndex);
                }
                else if(_boatConsole.ChoseType(choice))
                {
                    UpdateBoatType(mmbr, boatIndex);
                }
                else
                {
                    _boatConsole.NotValidInput();
                }
                
            }
            else
            {
                _boatConsole.MemberHasNoBoats();
            }
        }

        private void UpdateBoatLength(model.Member member, int index)
        {
            var boat = member.GetBoatList()[index];
            boat.UpdateBoatLength(_boatConsole.GetBoatLength());
        }

        private void UpdateBoatType(model.Member member, int index)
        {
            var boat = member.GetBoatList()[index];
            boat.UpdateBoatType(_boatConsole.GetBoatType());
        }

        public void ListBoats(model.Member mmbr)
        {
            var boatlist = mmbr.GetBoatList();

            foreach (var boat in boatlist)
            {
                _boatConsole.ListBoat(boatlist.IndexOf(boat), boat.GetBoatType(), boat.GetLength());
            }
        }

    }
}
