﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.controller
{
    class Administrator
    {
        private view.CommandConsole CommandConsole;

        private FileContent _fileContent;
        private BoatOperations _boatOperations;
        private MemberOperations _memberOperations;

        public Administrator(string path)
        {
            _fileContent = new FileContent(path);

            CommandConsole = new view.CommandConsole();
            _boatOperations = new BoatOperations(_fileContent.Register);
            _memberOperations = new MemberOperations(_fileContent.Register, _boatOperations);
            
            CommandOptions();
        }

        public void CommandOptions()
        {
            switch (CommandConsole.CommandOptions())
            {
                case "list -v":
                    _memberOperations.List(true);
                    CommandOptions();
                    break;
                case "list -c": 
                    _memberOperations.List(false);
                    CommandOptions();
                    break;
                case "list -m":
                    _memberOperations.ViewMember();
                    CommandOptions();
                    break;
                case "add -m":
                    _memberOperations.AddMemberToRegister();
                    UpdateFile();
                    break;
                case "add -b": 
                    _boatOperations.AddBoat();
                    UpdateFile();
                    break;
                case "delete -m": 
                    _memberOperations.DeleteMemberFromRegister();
                    UpdateFile();
                    break;
                case "delete -b":
                    _boatOperations.DeleteBoat();
                    UpdateFile();
                    break;
                case "change -m":
                    _memberOperations.ChangeMember();
                    UpdateFile();
                    break;
                case "change -b":
                    _boatOperations.ChangeBoat();
                    UpdateFile();
                    break;
                default:
                    CommandConsole.NotValidInput();
                    CommandOptions();
                    break;
            }
        }

        private void UpdateFile()
        {
            _fileContent.UpdateFile();
            CommandOptions();
        }
        
    }
}
