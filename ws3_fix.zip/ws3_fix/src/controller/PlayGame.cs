﻿using System;
using System.Collections.Generic;
using System.Threading;
namespace BlackJack.controller
{
    class PlayGame : model.ICardDealtObserver
    {
        private model.Game _game;
        private view.IView _view;
        private view.VarifyInput _userInput;

        public PlayGame(model.Game a_game, view.IView a_view)
        {
            _game = a_game;
            _view = a_view;
            _userInput = new view.VarifyInput();

            _game.addSubscriber(this);

            Start();
        }

        private void Start()
        {
            _view.DisplayWelcomeMessage();
            
            _view.DisplayPlayerHand();
            _view.DisplayDealerHand();
        }

        public bool Play()
        {
            int input = _view.GetInput();

            if (_userInput.WantsToPlay(input))
            {
                Start();
                _game.NewGame();
            }
            else if (_userInput.WantsToHit(input))
            {
                _game.Hit();
            }
            else if (_userInput.WantsToStand(input))
            {
                _game.Stand();
            }

            return _userInput.DoesNotWantToQuit(input);
        }

        public void CardDealt(bool isDealer, int score,  Object color, Object type)
        {
            _view.DisplayCard(color.ToString(), type, isDealer, score);                

            if (_game.IsGameOver())
            {
                _view.DisplayGameOver(_game.IsDealerWinner());
            }
        }
    }
}
