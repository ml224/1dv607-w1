﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack.view
{
    class VarifyInput
    {
        public bool WantsToPlay(int choice)
        {
            return choice == 'p';
        }
        public bool WantsToHit(int choice)
        {
            return choice == 'h';
        }

        public bool WantsToStand(int choice)
        {
            return choice == 's';
        }
        public bool DoesNotWantToQuit(int choice)
        {
            return choice != 'q';
        }
    }
}
