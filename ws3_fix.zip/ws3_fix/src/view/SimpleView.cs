﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace BlackJack.view
{
    class SimpleView : IView
    {
        private int playerY;
        private int dealerY;
        
        public void DisplayWelcomeMessage()
        {
            Console.Clear();
            System.Console.WriteLine("Hello Black Jack World");
            System.Console.WriteLine("Type 'p' to Play, 'h' to Hit, 's' to Stand or 'q' to Quit\n");
        }

        public int GetInput()
        {
            return Console.Read();
        }
        

        public void DisplayCard(string cardColor, Object cardValue, bool isDealer, int score)
        {
            string displayCard = $"{cardValue} of {cardColor}\nScore:{score}";
            
                Thread.Sleep(1500);

                if (isDealer)
                {
                    WriteAt(displayCard, dealerY);
                    dealerY++;
                }
                else
                {
                    WriteAt(displayCard, playerY);
                    playerY++;
                }
        }

        public void DisplayPlayerHand()
        {
            DisplayHand("Player", false);
        }

        public void DisplayDealerHand()
        {
            DisplayHand("Dealer", true);
        }

        private void DisplayHand(String a_name, bool isDealer)
        {
            Console.WriteLine($"{a_name} Has: \n");
            
            if (isDealer)
            {
                dealerY = Console.CursorTop;
                
            }
            else
            {
                playerY = Console.CursorTop;
                
            }

            Console.WriteLine("\n\n\n\n\n\n\n");
        }

        public void DisplayGameOver(bool a_dealerIsWinner)
        {
            Console.Write("GameOver: ");
            if (a_dealerIsWinner)
            {
                Console.WriteLine("Dealer Won!");
            }
            else
            {
                Console.WriteLine("You Won!");
            }
        }

        private void WriteAt(string s, int y)
        {
            try
            {
                Console.SetCursorPosition(0, y);
                Console.Write(s);
                Console.WriteLine("");
            }
            catch (ArgumentOutOfRangeException e)
            {
                Console.Clear();
                Console.WriteLine(e.Message);
            }
        }
    }
}
