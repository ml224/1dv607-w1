﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack.view
{
    interface IView
    {
        void DisplayWelcomeMessage();
        int GetInput();
        void DisplayCard(string cardColor, Object cardValue, bool isDealer, int score);
        void DisplayDealerHand();
        void DisplayPlayerHand();
        void DisplayGameOver(bool a_dealerIsWinner);
    }
}
