﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace YachtClub.view
{
    class UserInput
    {
        private view.Presentation _presentation = new Presentation();

        public string CommandOptions()
        {
                Console.WriteLine("\n\nCommands available: \n" +
                    "list -v = List Members Verbose View\n" +
                    "list -c = List Members Compact View\n" +
                    "list -m = List Member\n" +
                    "add -m = Add Member \n" +
                    "add -b = Add Boat To Member\n" +
                    "delete -m = Delete Member\n" +
                    "delete -b = Delete Boat\n" +
                    "change -m = Change Member Information\n" +
                    "change -b = Change Boat Information\n\n");
                return Console.ReadLine();
        }

        public long GetMemberID()
        {
            Console.WriteLine("Enter Member ID: ");
            string id = Console.ReadLine();
            
            while (!long.TryParse(id, out long result))
            {
                Console.WriteLine("Numbers only please! Try again: ");
                id = Console.ReadLine();
            }

            return long.Parse(id);
        }

        public string GetBoatType()
        {
            Console.WriteLine("Enter boat type: ");
            return Console.ReadLine();
        }
        
        public int GetBoatLength()
        {
            Console.WriteLine("Enter boat length (in m): ");
            var length = Console.ReadLine();

            while (!int.TryParse(length, out int result))
            {
                Console.WriteLine("Numbers only please! Try again:");
                length = Console.ReadLine();
            }

            return int.Parse(length);
        }

        public int GetBoatIndex(Dictionary<int, KeyValuePair<string, int>> boatList)
        {
            Console.WriteLine($"Enter the index of the boat:\n{_presentation.ListBoats(boatList)}");
            

            string index = Console.ReadLine();

            while (!int.TryParse(index, out int result) || int.Parse(index) >= boatList.Count)
            {
                Console.WriteLine("Try again:");
                index = Console.ReadLine();
            }
            
            return int.Parse(index);

        }

        public string ChangeMember()
        {
            Console.WriteLine("Type NAME for changing members name or PN for changing Personal Number: ");
            string returnable = Console.ReadLine().ToLower();

            while (returnable != "name" && returnable != "pn")
            {
                Console.WriteLine("Try Again: ");
                returnable = Console.ReadLine();
            }

            return returnable;
        }
        
        public string NewName()
        {
            Console.WriteLine("Enter new member name: ");
            return Console.ReadLine();
        }

        public long NewPN()
        {
            Console.WriteLine("Enter new personal number: ");
            string returnable = Console.ReadLine();

            while (!long.TryParse(returnable, out long longNr))
            {
                Console.WriteLine("Try again! You must enter only numbers: ");
                returnable = Console.ReadLine();
            }

            return long.Parse(returnable);
        }
    }
}
