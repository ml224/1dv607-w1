﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.view
{
    class Presentation
    {
        //list members
        public string CompactView(string name, long id, int boatAmount)
        {
            return $"-------------------------\nName: {name}\nMember ID: {id}\nNumber of boats: {boatAmount}";
        }

        public string VerboseView(string name, long id, long pn, Dictionary<int, KeyValuePair<string, int>> boats)
        {
            string str = $"-------------------------\nName: {name}\nMember ID: {id}\nPersonal Number: {pn}\nNumber of boats: {boats.Count()}";

            if (boats.Count() > 0)
            {
                str += ListBoats(boats);                
            }

            return str;
        }

        public string ListBoats(Dictionary<int, KeyValuePair<string, int>> boatList)
        {
            string returnValue = "";

            foreach (var boat in boatList)
            {
                returnValue += $"\n{boat.Key}. Type: {boat.Value.Key}, Length: {boat.Value.Value}";
            }
            return returnValue;
        }



        public void CommandErrorMessage()
        {
            Console.WriteLine("Please enter a valid command : ");

        }

        public void NoUserWithID()
        {
            Console.WriteLine($"no member with that id exists, try again: ");
        }

        public void MemberHasNoBoats()
        {
            Console.WriteLine("Member has no boats!");
        }
    }
}
