﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Reflection;

namespace YachtClub.controller
{
    class FileContent
    {
        private JArray _fileContent;
        private model.MemberRegister _register;
        private string _path;
        public FileContent(string path)
        {
            _path = path;
            _fileContent = JArray.Parse(File.ReadAllText(_path));

            Register = new model.MemberRegister();
            
            //populating Register with file content
            AddMembers();
        }

        public model.MemberRegister Register
        {
            get { return _register; }
            private set { _register = value; }
        }


        //only used upon creation of this class
        private void AddMembers()
        {
            foreach (var member in _fileContent)
            {
                var memberID = member["memberID"].ToObject<long>();
                var memberPn = member["personalNumber"].ToObject<long>();
                var memberName = member["name"].ToString();

                Register.AddMember(memberName, memberPn, memberID);

                if (member["boats"].Count() > 0)
                {
                    foreach(var boat in member["boats"])
                    {
                        Register.AddBoat(memberID, new KeyValuePair<string, int>(boat["type"].ToString(), boat["length"].ToObject<int>()));
                    }
                }
            }
        }

        private string addBoats(model.Member member)
        {
            string boats = "";
            var last = member.BoatList.Last();

            foreach (var boat in member.BoatList)
            {
                boats += @"{'type': '" + boat.Type + "', 'length': " + boat.Length + "}";

                if (boat != last)
                {
                    boats += ", ";
                }
            }

            return boats;
        }



        public void UpdateFile()
        {
            JArray members = new JArray();

            foreach (model.Member member in _register.MembersList)
            {
                string boats = "";

                if (member.BoatList.Count > 0)
                {
                    boats += addBoats(member);
                }

                string jsonString = "{ 'memberID' : " + member.MemberID + ", 'name': '" + member.Name + "', 'personalNumber': " +
                    member.PersonalNumber + ", 'boats': [" + boats + "]}";

                members.Add(JObject.Parse(jsonString));
            }

            _fileContent = members;

            File.WriteAllText(_path, _fileContent.ToString());
        }
    }
}

