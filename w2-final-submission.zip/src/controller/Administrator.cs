﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.controller
{
    class Administrator
    {
        private view.UserInput _userInput;
        private view.Presentation _presentation;
        private AdministratorOperations _adminOperations;

        public Administrator(string path)
        {
            _userInput = new view.UserInput();
            _presentation = new view.Presentation();
            _adminOperations = new AdministratorOperations(path);

            // prompts user with command options
            CommandOptions();
        }

        public void CommandOptions()
        {
            //operation based on user input
            switch (_userInput.CommandOptions())
            {
                case "list -v": //list members - verbose view
                    _adminOperations.List(true);

                    CommandOptions();
                    break;
                case "list -c": //list members - compact view
                    _adminOperations.List(false);

                    CommandOptions();
                    break;
                case "list -m": //view member
                    _adminOperations.ViewMember(GetUserId());
                    CommandOptions();
                    break;
                case "add -m": //add member
                    _adminOperations.AddMemberToRegister(_userInput.NewName(), _userInput.NewPN());
                    CommandOptions();
                    break;
                case "add -b": //add boat
                    _adminOperations.AddBoat(GetUserId(), _userInput.GetBoatLength(), _userInput.GetBoatType());
                    CommandOptions();
                    break;
                case "delete -m": //delete member
                    _adminOperations.DeleteMemberFromRegister(GetUserId());
                    CommandOptions();
                    break;
                case "delete -b": //delete boat
                    var mmbrID = GetUserId();
                    if (_adminOperations.MemberHasBoats(mmbrID))
                    {
                        int boatIndex = _userInput.GetBoatIndex(_adminOperations.ListBoats(mmbrID));
                        _adminOperations.DeleteBoat(mmbrID, boatIndex);
                    }
                    CommandOptions();
                    break;
                case "change -m": //change member information

                    if (_userInput.ChangeMember() == "name")
                    {
                        _adminOperations.UpdateMemberName(GetUserId(), _userInput.NewName());
                    }
                    else
                    {
                        _adminOperations.UpdateMembersPersonalNumber(GetUserId(), _userInput.NewPN());
                    }
                    CommandOptions();
                    break;
                case "change -b": //change boat information
                    var id = GetUserId();
                    if (_adminOperations.MemberHasBoats(id))
                    {
                        int boatIndex = _userInput.GetBoatIndex(_adminOperations.ListBoats(id));

                        KeyValuePair<string, int> newInfo = new KeyValuePair<string, int>(_userInput.GetBoatType(), _userInput.GetBoatLength());

                        _adminOperations.UpdateBoatInfo(id, boatIndex, newInfo);
                    } else
                    {
                        _presentation.MemberHasNoBoats();
                    }
                    CommandOptions();
                    break;
                default:
                    _presentation.CommandErrorMessage();
                    CommandOptions();
                    break;
            }
        }

        private long GetUserId()
        {
            long mmberID = _userInput.GetMemberID();

            while (_adminOperations.GetMember(mmberID) == null)
            {
                _presentation.NoUserWithID();
                mmberID = _userInput.GetMemberID();
            }
            return mmberID;
        }
    }
}
