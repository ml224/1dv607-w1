﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.controller
{
    class AdministratorOperations
    {
        private FileContent _fileContent;
        private model.MemberRegister _register;
        private view.Presentation _presentation;

        public AdministratorOperations(string path)
        {
            _fileContent = new FileContent(path);
            _register = _fileContent.Register;
            _presentation = new view.Presentation();
        }

        private long NewID()
        {
            long nr = 0;
            foreach (model.Member member in _register.MembersList)
            {
                if (nr <= member.MemberID)
                {
                    nr = member.MemberID + 1;
                }
            }
            return nr;
        }

        public void AddMemberToRegister(string name, long pn)
        {
            _register.AddMember(name, pn, NewID());
            _fileContent.UpdateFile();
        }

        public void DeleteMemberFromRegister(long id)
        {
            _register.DeleteMember(id);
            _fileContent.UpdateFile();
        }

        public void UpdateMembersPersonalNumber(long id, long newPN)
        {
            _register.UpdateMemberPersonalNumber(id, newPN);
            _fileContent.UpdateFile();
        }

        public void UpdateMemberName(long id, string newName)
        {
            _register.UpdateMemberName(id, newName);
            _fileContent.UpdateFile();
        }

        public void AddBoat(long id, int length, string type)
        {
            _register.AddBoat(id, new KeyValuePair<string, int>(type, length));
            _fileContent.UpdateFile();
        }

        public void DeleteBoat(long id, int index)
        {
            _register.RemoveBoat(id, index);
            _fileContent.UpdateFile();
        }

        public void UpdateBoatInfo(long id, int index, KeyValuePair<string, int> boatInfo)
        {
            _register.UpdateBoat(id, index, boatInfo);
            _fileContent.UpdateFile();
        }

        public Dictionary<int, KeyValuePair<string, int>> ListBoats(long id)
        {
            var boatList = _register.GetMemberByID(id).BoatList;
            Dictionary<int, KeyValuePair<string, int>> boats = new Dictionary<int, KeyValuePair<string, int>>();

            foreach (var boat in boatList)
            {
                boats.Add(boatList.IndexOf(boat), new KeyValuePair<string, int>(boat.Type, boat.Length));
            }

            return boats;
        }

        public bool MemberHasBoats(long id)
        {
            var member = _register.GetMemberByID(id);
            if (member != null)
            {
                return member.BoatList.Count > 0;

            }
            else
            {
                return false;
            }
        }

        public model.Member GetMember(long memberID)
        {
           return _register.GetMemberByID(memberID);
           
        }

        private Dictionary<int, KeyValuePair<string, int>> BoatListToDictionary(model.Member member)
        {
            Dictionary<int, KeyValuePair<string, int>> boatList = new Dictionary<int, KeyValuePair<string, int>>();

            foreach (var boat in member.BoatList)
            {
                boatList.Add(member.BoatList.IndexOf(boat), new KeyValuePair<string, int>(boat.Type, boat.Length));
            }

            return boatList;
        }

        public void List(bool isVerbose)
        {
            foreach (model.Member member in _fileContent.Register.MembersList)
            {
                if (isVerbose)
                {
                    Dictionary<int, KeyValuePair<string, int>> boatList = BoatListToDictionary(member);

                    Console.WriteLine(_presentation.VerboseView(member.Name, member.MemberID, member.PersonalNumber, boatList));
                }
                else
                {
                    Console.WriteLine(_presentation.CompactView(member.Name, member.MemberID, member.BoatList.Count));

                }
            }
        }

        public void ViewMember(long memberID)
        {
            var member = GetMember(memberID);
            Console.WriteLine(_presentation.VerboseView(member.Name, member.MemberID, member.PersonalNumber, BoatListToDictionary(member)));
        }
    }
}

