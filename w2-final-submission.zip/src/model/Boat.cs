﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YachtClub.model
{
    class Boat
    {

        public int _length;
        public string _type;

        public Boat(int length, string type)
        {
            _length = length;
            _type = type;
        }

        public string Type
        {
            get { return _type; }
            private set
            {
                _type = value;
            }
        }
        public int Length
        {
            get { return _length; }
            private set
            {
                _length = value;
            }
        }

        public void UpdateBoatType(string type)
        {
            Type = type;
        }

        public void UpdateBoatLength(int length)
        {
            Length = length;
        }
    }
}
