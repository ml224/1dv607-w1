﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json.Linq;


namespace YachtClub.model
{
    class Member
    {
        public Member(string name, long personalNumber, long memberID)
        {
            Name = name;
            PersonalNumber = personalNumber;
            MemberID = memberID;
            BoatList = new List<Boat>();
        }
        
        public long MemberID { get; private set; }

        public long PersonalNumber{ get; private set; }

        public string Name { get; private set; }

        public List<Boat> BoatList { get; private set; }

        public void UpdateMemberName(string newName)
        {
            Name = newName;
        }

        public void UpdateMemberPersonalNumber(long newPersonalNumber)
        {
            PersonalNumber = newPersonalNumber;
        }

        //boat stuff
        public void AddBoat(string type, int length)
        {
            BoatList.Add(new Boat(length, type));
        }

        public void RemoveBoat(int index)
        {
            if(index < BoatList.Count)
            {
                BoatList.Remove(BoatList[index]);

            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }
        }

        public void UpdateBoatInfo(int index, string type, int length)
        {
            RemoveBoat(index);
            AddBoat(type, length);
        }

    }
}

   


