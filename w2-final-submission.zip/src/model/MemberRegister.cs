﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Reflection;
using System.Data;


namespace YachtClub.model
{
    class MemberRegister
    {
        public MemberRegister()
        {
            MembersList = new List<Member>();
        }

        public List<Member> MembersList { get; private set; }

        public Member GetMemberByID(long id)
        {
            return MembersList.Find(m => m.MemberID == id);
        }

        //CRUD stuff
        public void AddMember(string name, long personalNumber, long memberID)
        {
            MembersList.Add(new Member(name, personalNumber, memberID));
        }

        public void DeleteMember(long memberID)
        {
                MembersList.Remove(GetMemberByID(memberID));
        }

        public void UpdateMemberName(long memberID, string newName)
        {
            Member member = GetMemberByID(memberID);
                member.UpdateMemberName(newName);
        }
        
        public void UpdateMemberPersonalNumber(long memberID, long newPersonalNumber)
        {
            Member member = GetMemberByID(memberID);

                member.UpdateMemberPersonalNumber(newPersonalNumber);
        }

        public void AddBoat(long id, KeyValuePair<string, int> boatInfo)
        {
            GetMemberByID(id).AddBoat(boatInfo.Key, boatInfo.Value);
        }

        public void RemoveBoat(long id, int index)
        {
            GetMemberByID(id).RemoveBoat(index);
        }

        

        public void UpdateBoat(long id, int index, KeyValuePair<string, int> boatInfo)
        {
            GetMemberByID(id).UpdateBoatInfo(index, boatInfo.Key, boatInfo.Value);
        }
    }
}

