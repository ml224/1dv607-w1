﻿using System;
using System.Collections.Generic;
using System.Threading;
namespace BlackJack.controller
{
    class PlayGame : model.ICardDealtObserver
    {
        private model.Game _game;
        private view.IView _view;

        public PlayGame(model.Game a_game, view.IView a_view)
        {
            _game = a_game;
            _view = a_view;

            _game.addSubscriber(this);

            Start();
        }

        private void Start()
        {
            _view.DisplayWelcomeMessage();
            
            _view.DisplayPlayerHand();
            _view.DisplayDealerHand();
        }

        public bool Play()
        {
            int input = _view.GetInput();

            if (input == 'p')
            {
                Start();
                _game.NewGame();
            }
            else if (input == 'h')
            {
                _game.Hit();
            }
            else if (input == 's')
            {
                _game.Stand();
            }

            return input != 'q';
        }

   


        public void CardDealt(bool isDealer, int score,  Object color, Object type)
        {
            _view.DisplayCard(color.ToString(), type, isDealer, score);                

            if (_game.IsGameOver())
            {
                _view.DisplayGameOver(_game.IsDealerWinner());
            }
        }
    }
}
