﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack.model.rules
{
    class Soft17NewGameStrategy : INewGameStrategy
    {
        private Soft17HitStrategy hitStrategy = new Soft17HitStrategy();

        public bool NewGame(Deck a_deck, Dealer a_dealer, Player a_player)
        {
            a_dealer.DealCard(a_player, true);
            
            a_dealer.DealCard(a_dealer, true);

            a_dealer.DealCard(a_player, true);

            if (hitStrategy.DoHit(a_dealer))
            {
                a_dealer.DealCard(a_dealer, true);
            }
          

            return true;
        }
    }
}
