﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack.model.rules
{
    class Soft17HitStrategy : IHitStrategy
    {
        private const int g_hitLimit = 17;
        private const int g_max = 21;
        private bool containsAce(Player a_dealer)
        {
            bool returnable = false;
            foreach(Card c in a_dealer.GetHand())
            {
                if(c.GetValue().Equals(Card.Value.Ace))
                {
                    returnable = true;
                }
            }
            return returnable;
        }

        private bool IsLessThanLimit(int score)
        {
            return score < g_hitLimit;
        }

        private bool IsHitLimit(int score)
        {
            return score == g_hitLimit;
        }
        

        public bool DoHit(Player a_dealer)
        {
            var dealerScore = a_dealer.CalcScore();


            if (IsLessThanLimit(dealerScore))
            {
                return true;
            }
            if(IsHitLimit(dealerScore) && containsAce(a_dealer))
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }
    }
}
