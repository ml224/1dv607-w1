﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlackJack.model.rules
{
    class WinnerStrategyBenefitDealer : IWinnerStrategy
    {
        public bool IsDealerWinner(int dealerTotal, int playerTotal)
        {

            return dealerTotal >= playerTotal;
        }
    }
}
